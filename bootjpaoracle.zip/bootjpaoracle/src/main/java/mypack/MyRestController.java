package mypack;


import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/*import mypack.model.Address;
import mypack.model.Employee;
*/
@RestController
public class MyRestController {
	
	
	
	
	/*
	 * @RequestMapping(value="employee", method=RequestMethod.GET) public Employee
	 * getEmployee(){ Employee emp = new Employee(); emp.setId(100);
	 * emp.setName("David"); emp.setPermanent(false); emp.setPhoneNumbers(new long[]
	 * { 123456, 987654 }); emp.setRole("Manager");
	 * 
	 * Address add = new Address(); add.setCity("Bangalore");
	 * add.setStreet("BTM 1st Stage"); add.setZipcode(560100); emp.setAddress(add);
	 * 
	 * List<String> cities = new ArrayList<String>(); cities.add("Los Angeles");
	 * cities.add("New York"); emp.setCities(cities);
	 * 
	 * Map<String, String> props = new HashMap<String, String>();
	 * props.put("salary", "1000 Rs"); props.put("age", "28 years");
	 * emp.setProperties(props);
	 * 
	 * return emp;
	 * 
	 * }
	 * 
	 * 
	 * @RequestMapping(value="product", method=RequestMethod.GET) public Product
	 * getProduct(){ SubProduct sb=new SubProduct(); sb.setName("subprod1"); Product
	 * prod=new Product(); prod.setId(202); prod.setName("electronicproduct");
	 * prod.setSubProduct(sb); return prod;
	 * 
	 * }
	 * 
	 * @RequestMapping(value="employee", method=RequestMethod.POST) public void
	 * addEmployee(@RequestBody Employee employee){
	 * System.out.println("***employee received is below***");
	 * System.out.println(employee); }
	 * 
	 * 
	 * @RequestMapping(value="product", method=RequestMethod.POST) public void
	 * addProduct(@RequestBody Product product){
	 * System.out.println("***product received is below***");
	 * System.out.println(product); }
	 * 
	 * @RequestMapping(value="region", method=RequestMethod.POST) public void
	 * addRegion(@RequestBody Region region){
	 * System.out.println("***Region received is below***");
	 * System.out.println(region); }
	 * 
	 * @RequestMapping(value="region", method=RequestMethod.GET) public Region
	 * processRequest(){ Region region1=new Region(); region1.setId(1);
	 * region1.setName("north"); return region1;
	 * 
	 * }
	 * 
	 * @RequestMapping(value = "regions", method = RequestMethod.GET) public
	 * List<Region> list() { ArrayList<Region> list=new ArrayList<Region>(); Region
	 * region1=new Region(); region1.setId(1); region1.setName("North"); Region
	 * region2=new Region(); region2.setId(2); region2.setName("South");
	 * list.add(region1); list.add(region2); return list; }
	 * 
	 * 
	 * 
	 * @RequestMapping(value = "regions/{id}", method = RequestMethod.GET) public
	 * Region get(@PathVariable int id) { ArrayList<Region> list=new
	 * ArrayList<Region>(); Region region1=new Region(); region1.setId(1);
	 * region1.setName("north"); Region region2=new Region(); region2.setId(2);
	 * region2.setName("South"); list.add(region1); list.add(region2); return
	 * list.get(id); }
	 * 
	 * @RequestMapping(value = "regiondel/{id}", method = RequestMethod.DELETE)
	 * public Region deleteRegion(@PathVariable int id) {
	 * 
	 * ArrayList<Region> list=new ArrayList<Region>(); Region region1=new Region();
	 * region1.setId(1); region1.setName("north"); Region region2=new Region();
	 * region2.setId(2); region2.setName("South"); list.add(region1);
	 * list.add(region2); Region reg=list.remove(id); System.out.println(reg+
	 * ": removed"); return reg; }
	 * 
	 * @RequestMapping(value = "region/{id}", method = RequestMethod.PUT) public
	 * Region update(@PathVariable int id, @RequestBody Region region) {
	 * System.out.println("updated:");
	 * 
	 * System.out.println(region); return region; }
	 */

}
